"""Offline HTTP replay of seven flows with real local ASR and fake TTS/Clinic/Redis."""

import io
import json
import os
import socket
import sys
import wave
from datetime import datetime
from pathlib import Path
from time import perf_counter
from uuid import uuid4

sys.path.insert(0, str(Path(r"C:\callbot-vinmec")))

for key in (
    "OPENAI_API_KEY", "VBEE_API_TOKEN", "VBEE_APP_ID", "ELEVENLABS_API_KEY",
    "GEMINI_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY",
    "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY",
):
    os.environ[key] = ""
os.environ.update(
    NAME_FALLBACK_PROVIDER="none", SEMANTIC_FALLBACK_ENABLED="false",
    TRACE_ENABLED="false", LANGFUSE_EXPORT_ENABLED="false",
)

import httpx

blocked = []


def no_http(*args, **kwargs):
    blocked.append("http")
    raise RuntimeError("Real HTTP transport is forbidden in offline replay")


httpx.HTTPTransport.handle_request = no_http
httpx.AsyncHTTPTransport.handle_async_request = no_http
original_connect = socket.socket.connect
original_connect_ex = socket.socket.connect_ex


def guarded_connect(self, address):
    if isinstance(address, tuple) and address[0] not in ("127.0.0.1", "localhost", "::1"):
        blocked.append("socket")
        raise RuntimeError("External sockets forbidden")
    return original_connect(self, address)


def guarded_connect_ex(self, address):
    if isinstance(address, tuple) and address[0] not in ("127.0.0.1", "localhost", "::1"):
        blocked.append("socket")
        raise RuntimeError("External sockets forbidden")
    return original_connect_ex(self, address)


socket.socket.connect = guarded_connect
socket.socket.connect_ex = guarded_connect_ex

import fakeredis
from fastapi.testclient import TestClient
from callbot.engine import EngineSettings, RedisSessionStore
from callbot.engine.dialogue import templates
from callbot.engine.extraction.schema import VN_TZ
from callbot.transports.http import calls as http_calls
from callbot.transports.http.call_mode import CallModeStore
from callbot.transports.http.main import create_app
from clinic_mock_sim import FakeClinicAPI
from inference.asr import create_asr_gateway
from speech.asr.recognizer import SpeechRecognizer
from speech.audio.codec import decode_wav
from tests.transports.http.fakes import make_speech_bundle
from tests.transports.http.test_audio_parity import _records
from tests.transports.http.test_calls import _start, _turn

ROOT = Path(__file__).resolve().parent
SOURCE = Path(r"C:\qa-audio-20260928\wav")
REPO = Path(r"C:\callbot-vinmec")
templates.choose_variant = lambda ctx, group: "v0"
asr = SpeechRecognizer(create_asr_gateway("zipformer"))

# Token timestamps locate TÔI at 1.88 seconds; retain 0.10 seconds before it.
# Write only a new file in the workspace. Never alter the original recording.
trimmed = ROOT / "clips" / "QA_BOOKING_REQUEST_clean.wav"
trimmed.parent.mkdir(parents=True, exist_ok=True)
with wave.open(str(SOURCE / "QA_BOOKING_REQUEST.wav"), "rb") as src:
    params = src.getparams()
    src.setpos(round(1.78 * params.framerate))
    frames = src.readframes(params.nframes)
with wave.open(str(trimmed), "wb") as dst:
    dst.setparams(params)
    dst.writeframes(frames)

paths = {
    "name": REPO / "eval/stt-bench/audio-8k/STT_ID_02.wav",
    "dob": REPO / "eval/stt-bench/audio-8k/STT_DOB_01.wav",
    "confirm": REPO / "eval/stt-bench/audio-8k/STT_CF_01.wav",
    "cancel": SOURCE / "QA_CANCEL_EXPLICIT.wav",
    "transfer": SOURCE / "QA_TRANSFER_HUMAN.wav",
    "reschedule": SOURCE / "QA_RESCHEDULE_REQUEST.wav",
    "slot": SOURCE / "QA_SLOT_FIRST.wav",
    "agree": SOURCE / "QA_SLOT_CONFIRM_EXPLICIT.wav",
    "book": trimmed,
}
decoded = {}
for key, path in paths.items():
    result = asr.transcribe(decode_wav(path.read_bytes()))
    decoded[key] = {"text": result.text, "confidence": result.confidence, "path": str(path)}
    print("CLIP", key, result.text, flush=True)
assert decoded["book"]["text"].strip().upper() == "TÔI MUỐN ĐẶT LỊCH KHÁM", decoded["book"]

scenarios = [
    ("identity", {}, ["name", "dob"], None),
    ("confirm", {}, ["name", "dob", "confirm"], "CONFIRMED"),
    ("cancel", {}, ["name", "dob", "cancel", "cancel"], "CANCELLED"),
    ("transfer", {}, ["transfer"], "TRANSFERRED"),
    ("reschedule", {}, ["name", "dob", "reschedule", "slot", "agree"], "RESCHEDULED"),
    ("no_answer", {}, [None, None, None], "UNREACHABLE"),
    ("booking", {"direction": "inbound", "appointment_id": None, "caller_number": "0912345600"},
     ["name", "dob", "book", "slot", "agree"], "BOOKED"),
]
report = {
    "scope": "HTTP in-process, real Zipformer ASR, real input upload/decode, fake TTS/Clinic/fakeredis",
    "clock": "2026-10-06T10:00:00+07:00",
    "trim": {"source": str(SOURCE / "QA_BOOKING_REQUEST.wav"), "output": str(trimmed), "start_seconds": 1.78},
    "clips": decoded,
    "flows": [],
}

for scenario, start, keys, expected in scenarios:
    comparisons = []
    evidence = []
    try:
        for mode in ("text", "audio"):
            clinic = FakeClinicAPI()
            redis_server = fakeredis.FakeServer()
            prefix = "w4_replay:" + uuid4().hex

            def make_store():
                return RedisSessionStore(
                    fakeredis.FakeRedis(server=redis_server, decode_responses=True), key_prefix=prefix
                )

            speech = make_speech_bundle(ROOT / "replay-output" / scenario / mode, base_url="http://testserver")
            if mode == "audio":
                speech.asr = asr
            app = create_app(
                clinic_factory=lambda: clinic,
                engine_settings=EngineSettings(name_fallback_provider="none", semantic_fallback_enabled=False),
                session_store_factory=make_store,
                speech_factory=lambda: speech,
                call_mode_factory=lambda: CallModeStore(
                    fakeredis.FakeRedis(server=redis_server, decode_responses=True), key_prefix=prefix
                ),
            )
            with TestClient(app) as client:
                app.state.orchestrator.sessions._clock = lambda: datetime(2026, 10, 6, 10, tzinfo=VN_TZ)

                def load_from_testclient(url):
                    response = client.get(url)
                    assert response.status_code == 200
                    return decode_wav(response.content)

                http_calls.load_from_url = load_from_testclient
                call_id = f"w4_{scenario}_{mode}"
                opening = _start(client, call_id, mode=mode, **start)
                assert opening.status_code == 200, opening.text
                bodies = [opening.json()]
                snapshots = []
                turns = []
                audio_checks = []

                def check_audio(url):
                    response = client.get(url)
                    assert response.status_code == 200
                    with wave.open(io.BytesIO(response.content)) as wav:
                        assert wav.getframerate() == 8000
                        assert wav.getnchannels() == 1 and wav.getsampwidth() == 2 and wav.getnframes() > 0
                    audio_checks.append(url)

                if mode == "audio":
                    check_audio(bodies[0]["audio_url"])
                for turn, key in enumerate(keys, 1):
                    audio_url = None
                    if mode == "audio" and key is not None:
                        upload = client.put(
                            f"/demo-api/audio/{call_id}/{turn}.wav", content=paths[key].read_bytes(),
                            headers={"Content-Type": "audio/wav"},
                        )
                        assert upload.status_code == 200, upload.text
                        audio_url = upload.json()["audio_url"]
                    started = perf_counter()
                    response = _turn(
                        client, call_id, turn, decoded[key]["text"] if mode == "text" and key else None,
                        silence_ms=2000 if key is None else 0, audio_url=audio_url,
                    )
                    assert response.status_code == 200, response.text
                    body = response.json()
                    bodies.append(body)
                    if mode == "audio":
                        check_audio(body["audio_url"])
                    session = app.state.session_store.get_session(call_id)
                    ctx = session.context
                    snapshots.append({field: ctx.get(field) for field in (
                        "state", "turn", "identity_verified", "silent_turns", "failed_understandings",
                        "selected_slot_id", "pending_action", "presented_slot_ids",
                    )})
                    turns.append({"turn": turn, "clip": key, "state": body["state"],
                                  "outcome": body["outcome"], "elapsed_ms": round((perf_counter()-started)*1000, 2)})
                assert bodies[-1]["outcome"] == expected
                assert bodies[-1]["ended"] == (expected is not None)
                if mode == "audio":
                    assert speech.tts.spoken == [body["utterance"] for body in bodies]
                else:
                    assert speech.tts.spoken == []
                assert len(clinic.writes) == (0 if expected is None else 1)
                comparisons.append({
                    "bodies": [{k: v for k, v in body.items() if k not in ("call_id", "audio_url")} for body in bodies],
                    "snapshots": snapshots, "writes": clinic.writes, "records": _records(clinic),
                    "api": [(c.operation, c.method, c.path, c.status, c.code) for c in clinic.calls],
                })
                evidence.append({"mode": mode, "turns": turns, "audio_count": len(audio_checks),
                                 "writes": clinic.writes, "comparison": comparisons[-1]})
        assert comparisons[0] == comparisons[1], "Text/audio state or API comparison differs"
        row = {"flow": scenario, "passed": True, "outcome": expected, "evidence": evidence}
        print("FLOW", scenario, "PASS", expected, flush=True)
    except Exception as exc:
        row = {"flow": scenario, "passed": False, "error": type(exc).__name__, "detail": str(exc), "evidence": evidence}
        print("FLOW", scenario, "FAIL", type(exc).__name__, str(exc), flush=True)
    report["flows"].append(row)
    (ROOT / "real-audio-replay.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

report["passed_flows"] = sum(row["passed"] for row in report["flows"])
report["blocked_network_attempts"] = len(blocked)
(ROOT / "real-audio-replay.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
print("SUMMARY", report["passed_flows"], "/ 7; external attempts", len(blocked), flush=True)
sys.exit(0 if report["passed_flows"] == 7 and not blocked else 1)
